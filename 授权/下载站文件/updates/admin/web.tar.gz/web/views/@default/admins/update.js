Tea.context(function () {
	this.success = NotifySuccess("保存成功", "/admins/admin?adminId=" + this.admin.id)
})