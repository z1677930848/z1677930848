Tea.context(function () {
	this.success = NotifySuccess("保存成功", "/servers/metrics/item?itemId=" + this.item.id)
})