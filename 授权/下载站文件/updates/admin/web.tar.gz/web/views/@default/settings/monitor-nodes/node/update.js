Tea.context(function () {
	this.success = NotifySuccess("保存成功", "/settings/monitorNodes/node?nodeId=" + this.node.id)
})