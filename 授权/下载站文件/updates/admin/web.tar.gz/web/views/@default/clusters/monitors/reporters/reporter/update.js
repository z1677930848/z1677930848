Tea.context(function () {
	this.success = NotifySuccess("保存成功", Tea.url(".", {reporterId: this.reporter.id}))
})