Tea.context(function () {
	this.success = NotifySuccess("保存成功", "/db/node?nodeId=" + this.node.id)
})