Tea.context(function () {
	this.success = NotifyPopup

	this.policyType = this.types[0].type
})