Tea.context(function () {
	this.close = NotifyPopup
})