Tea.context(function () {
	this.isSuper = false
})