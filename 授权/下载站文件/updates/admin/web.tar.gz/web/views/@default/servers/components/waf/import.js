Tea.context(function () {
	this.success = NotifyReloadSuccess("导入成功")
})