Tea.context(function () {
	this.method = this.grant.method;

	this.success = NotifyPopup;
});