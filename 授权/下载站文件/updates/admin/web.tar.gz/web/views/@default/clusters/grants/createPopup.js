Tea.context(function () {
	this.method = "user";

	this.success = NotifyPopup;
});