Tea.context(function () {
	this.cleanType = "all"
	this.days = 30

	this.success = NotifyReloadSuccess("清理完成")
})