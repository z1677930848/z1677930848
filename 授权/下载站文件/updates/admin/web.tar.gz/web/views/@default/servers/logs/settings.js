Tea.context(function () {
	this.success = NotifyReloadSuccess("保存成功，将会在一分钟之内生效")
})