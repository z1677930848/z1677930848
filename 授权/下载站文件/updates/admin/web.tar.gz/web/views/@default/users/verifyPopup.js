Tea.context(function () {
	this.result = "pass"
})