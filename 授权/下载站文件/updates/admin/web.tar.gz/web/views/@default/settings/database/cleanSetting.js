Tea.context(function () {
    this.success = NotifyReloadSuccess("保存成功")
})