Tea.context(function () {
	this.method = "user";

	this.success = NotifySuccess("保存成功", "/clusters/grants");
});