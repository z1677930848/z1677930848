package dns

import (
	_ "github.com/go-sql-driver/mysql"
)
